INTERNET PROGRAMMING LAB — EXPERIMENT 4
ONLINE TRAIN RESERVATION SYSTEM

AIM
To design and develop a responsive online train reservation website using HTML, CSS and JavaScript.

SOFTWARE REQUIREMENTS
- Any modern web browser (Chrome, Edge, Firefox)
- A text editor such as Notepad or VS Code
- No server or internet connection is required

PROCEDURE
1. Extract Experiment4_Train_Reservation.zip.
2. Open index.html in a web browser.
3. Log in with demo username: student and password: 1234.
4. Select origin, destination, journey date, class and passenger count.
5. Click Search Trains and select a train using its radio button.
6. Enter passenger name and age, select a demo payment mode, and click Book Selected Train.
7. Note the generated PNR number and ticket details.
8. Enter that PNR in Check PNR Status to see the booking status.
9. In Booking History, click Cancel and confirm to see the demo refund estimate.
10. Click Print Ticket to print/save the sample ticket.

EXPECTED OUTPUT
- Login success message
- Train search results with train number, route, time, seats and fare
- Booking confirmation with a generated 10-digit sample PNR
- PNR status result
- Booking history with cancellation and estimated refund
- Print-friendly ticket

IMPORTANT LIMITATIONS
This is a front-end lab demonstration. Train data, seat counts, login, payment, PNR and refund are simulated in JavaScript. Bookings remain in memory only while the page stays open; refreshing the page clears them. It does not connect to Indian Railways, a real payment gateway, email, or a database. Do not enter real payment information.

SAMPLE TEST
Username: student
Password: 1234
Origin: Chennai
Destination: Bengaluru
Journey date: choose today or a future date
Class: Sleeper
Passengers: 1
Expected: Chennai Express and City Intercity appear as sample choices; select one to create a sample ticket.
