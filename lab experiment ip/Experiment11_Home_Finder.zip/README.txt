INTERNET PROGRAMMING LAB — EXPERIMENT 11
HOME FINDER — ONLINE REAL ESTATE PROPERTY SEARCH SYSTEM

AIM
To design and develop a friendly and responsive real estate website using HTML, CSS and JavaScript. It lets users search properties by location, type and budget, save search criteria, view property details, find agents, save favorites, request visits and open the property's area in Google Maps.

SOFTWARE REQUIREMENTS
- A modern web browser (Chrome, Edge, Firefox)
- Notepad or Visual Studio Code
- Internet is required only to open external links / Google Maps; the main demo runs locally.

PROCEDURE
1. Extract Experiment11_Home_Finder.zip.
2. Open index.html in a web browser.
3. In Buyer Login / Registration, enter a demo username and password, then click Login / Register.
4. Choose location, property type, minimum budget and maximum budget.
5. Click Search Properties to view matching listings.
6. Click Save Search Criteria to store the current filters; click Load Saved Search to reuse them.
7. Click Favorite on a listing to add it to favorites.
8. Click View area to show the area name and enable the Google Maps link.
9. Search for an agent or company in the Agents section.
10. Use Advertisements & Useful Links to open external property websites or calculate an illustrative mortgage EMI.
11. Submit a property visit request using a name and future date.
12. Review favorites, visit requests and the local visitor counter.

EXPECTED OUTPUT
- Home Finder landing page
- Buyer login / demo registration message
- Property search results filtered by location, price and type
- Saved and reloaded search criteria
- Property cards with price, type, size, area and agent
- Agent/company search results
- Google Maps search link for a selected property area
- Favorites, visit request records and visitor count
- Mortgage EMI estimate

IMPORTANT LIMITATIONS
This is a front-end educational demonstration. It uses fictional property and agent records. localStorage is used for demo accounts, saved criteria, favorites, visit requests and a browser-local visit count. Passwords are NOT securely stored; the demo stores a password field in localStorage only to illustrate the idea, so use a fake password. Do not use real credentials. A production website must use a server-side database, secure password hashing, proper authentication, privacy protections and server-side visitor analytics. Google Maps is opened as an external search link; this is not an embedded interactive map. No real property transaction or visit booking is completed.

SAMPLE TEST
Username: student
Password: demo123
Location: Chennai
Type: Any type
Minimum budget: 0
Maximum budget: 7000000
Expected matching example listings include Sunny Family House and Compact Starter Flat is not in Chennai, so results depend on chosen location and budget. For Chennai up to ₹7,000,000, Sunny Family House is shown.
